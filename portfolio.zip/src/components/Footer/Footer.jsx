import React from 'react'
import './Footer.css'

function Footer() {
  return (
    <>
        <div className=' mt-5 mb-3 mx-auto text-center'>
        <h5 className= ' footer'> Portfolio  -  Innovatively Yours: © 2023  🌟  Powered by Webflow</h5>
        </div>    
    </>
  )
}

export default Footer