import logo from './logo.svg';
import './App.css';
import Background from './components/Background/Background';


function App() {
  return (
    <>
        <Background></Background>
    </>
  );
}

export default App;
